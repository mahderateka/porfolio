---
title: "{{ replace .Name "-" " " | title }}"
subtitle: ""
excerpt: ""
date: {{ .Date }}
author: ""
draft: true
images:
-  # url to thumbnail image
-  # url to feature image
series:
tags:
categories:
layout: single # single or single-sidebar
---
