---
title: Contact
name: Contact Us Form
description: "This template has a **contact-us** form built right in. All you need to do is add a valid recipient email address or form-id to the front matter of this form page and you're ready to receive submissions."
date: 2019-02-25T13:38:41-06:00
draft: false
url: contact
type: form
layout: split-right # split-right or split-left
submit_button_label: Send Message
show_social_links: true # specify social accounts in site config
show_poweredby_formspree: true
formspree_form_id: your@email.here
---

** Contact page don't contain a body, just the front matter above.
See form.html in the layouts folder **
