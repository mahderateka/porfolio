---
title: A Blog That's Real
description: "This is a fully featured blog that supports categories, tags, series, and pagination."
author: The Team at Formspree
images:
  - https://via.placeholder.com/960x480?text=SECTION+IMAGE
date: 2019-02-20T09:31:27-06:00
publishDate: 2019-02-20T09:31:27-06:00
layout: list-sidebar # list, list-sidebar, list-grid
show_post_thumbnail: true
show_author_byline: true
show_post_date: true
show_disqus_comments: false # see disqusShortname in site config
---

** No content for the blog index. This file provides front matter for the blog including the layout and boolean options. **
